# utils/config.py

# Signal Scoring Configuration
MIN_SIGNAL_SCORE = 4  # Minimum score out of 6 to send a signal (adjust as needed)

# Telegram Configuration
TELEGRAM_TOKEN = '8123034561:AAFUmL-YVT2uybFNDdl4U9eKQtz2w1f1dPo'
TELEGRAM_CHAT_ID = '5689209090'

# Discord Configuration
DISCORD_WEBHOOK_URL = 'https://discord.com/api/webhooks/1398658870980644985/0fHPvafJv0Bi6uc0RzPITEzcKgqKt6znfhhrBy-4qFBas8BfxiTxjyFkVqtp_ctt-Ndt'

# Allowed Trading Sessions
